### A simple front-end pixel art application.

Created Semptember 1, 2017, project prompt from Udacity Front-End-Web-Dev. 

Hosted on Heroku: https://frozen-tundra-56793.herokuapp.com/index.html
